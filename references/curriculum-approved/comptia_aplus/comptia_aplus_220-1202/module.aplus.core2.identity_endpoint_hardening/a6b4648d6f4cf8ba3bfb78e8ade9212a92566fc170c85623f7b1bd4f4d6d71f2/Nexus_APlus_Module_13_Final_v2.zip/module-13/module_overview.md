---
certification: comptia_aplus
certification_version: comptia_aplus_220-1202
domain: '2.0'
module_key: module.aplus.core2.identity_endpoint_hardening
title: Identity, Windows Endpoint & Workstation Hardening
objectives:
- '2.1'
- '2.2'
- '2.7'
---
# Identity, Windows Endpoint & Workstation Hardening

## Purpose
Turn Windows administration knowledge into safe security-support decisions. Students learn to identify the right control, collect evidence before changing security settings, preserve least privilege, protect data at rest, and harden a workstation without breaking legitimate work.

## Outcomes
By the end of this module, the student can:
- distinguish physical, logical, identity, and access controls at an A+ support level;
- inspect Windows security posture using built-in tools;
- reason about local/domain accounts, groups, UAC, NTFS/share permissions, and Active Directory support boundaries;
- choose appropriate encryption and workstation-hardening controls;
- avoid unsafe shortcuts such as permanent administrator membership or disabling protection to “make it work”;
- explain and document a defensible support decision.

## Relationship to earlier Nexus modules
- **Module 3:** Review Windows configuration/support surfaces.
- **Module 5:** Deep Dive on approval, escalation, evidence, documentation, and change control.
- **Module 11:** Deep Dive from Windows administration into Windows security administration.
- **Module 12:** Review safe application-support decisions across managed endpoints.
