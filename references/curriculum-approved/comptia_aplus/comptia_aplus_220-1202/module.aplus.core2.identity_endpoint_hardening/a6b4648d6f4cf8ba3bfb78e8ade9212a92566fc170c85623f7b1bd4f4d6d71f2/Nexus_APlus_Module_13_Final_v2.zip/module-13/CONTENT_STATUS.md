# CONTENT STATUS — Module 13

## Module
**Identity, Windows Endpoint & Workstation Hardening**

**Verdict: READY**

## Objective coverage
Official 220-1202 V15 objectives: 2.1, 2.2, 2.7

Question objective distribution (multi-objective items count toward each mapped objective):
- 2.1: 11
- 2.2: 22
- 2.7: 12

## Lessons
- Lesson count: 6
- Lesson importance: Job Critical 5 / Working Knowledge 1 / Awareness 0
- Learning relationship: New 2 / Review 1 / Deep Dive 3
- Frontmatter validation: PASS
- Every lesson has at least one required teaching resource: PASS
- Quick Checks: 24 explicit machine-readable references; 4 per lesson; all resolve to approved questions; manual editorial mapping review: PASS.
- Lesson → resource → question alignment: PASS

## Quick Check mappings
- `lesson.aplus.security.identity_controls`: `M13Q001`, `M13Q002`, `M13Q003`, `M13Q004`
- `lesson.aplus.security.windows_defender_firewall`: `M13Q005`, `M13Q006`, `M13Q007`, `M13Q008`
- `lesson.aplus.security.permissions_ad`: `M13Q009`, `M13Q010`, `M13Q011`, `M13Q012`
- `lesson.aplus.security.encryption`: `M13Q013`, `M13Q014`, `M13Q015`, `M13Q016`
- `lesson.aplus.security.workstation_hardening`: `M13Q017`, `M13Q018`, `M13Q019`, `M13Q020`
- `lesson.aplus.security.secure_support_decisions`: `M13Q021`, `M13Q022`, `M13Q023`, `M13Q024`
- Total references: 24
- Manual lesson/question alignment review: PASS
- Duplicate within a lesson Quick Check: 0
- Unsupported question types selected: 0 (all selected items are approved single-choice questions)

## Question bank
- Total: 36
- Single-choice: 28
- Multi-select: 4
- Short-answer: 2
- Free-response: 2
- Editorial results: 36 APPROVE / 0 EDIT / 0 REPLACE / 0 REMOVE / 0 NEEDS SOURCE VERIFICATION

### Single-choice answer positions
- A: 7
- B: 7
- C: 7
- D: 7

### Question importance
- Job Critical: 27
- Working Knowledge: 7
- Awareness: 2

### Question style
- Foundation: 17
- Scenario/Application: 9
- Troubleshooting/Reasoning: 10

### Provenance
- Existing Nexus concepts adapted: 11
- Permitted third-party concepts adapted/re-written: 9
- New/source-guided gap-fill: 16
- Verbatim third-party questions imported: 0
- Archived weak banks restored wholesale: 0

## Module Quiz
- Displayed: 12
- Pass threshold: 70%
- 12-question validation witness: PASS
- Objective/category constraints: satisfiable
- Multi-select minimum: PASS
- Scenario/reasoning minimum: PASS
- Answer-position guardrail: PASS

## Resources
- Total: 9
- Required: 6
- Optional: 3
- URL validation: 9/9 current resource destinations verified during the 2026-09-01 research pass (Professor Messer and Microsoft).
- Duplicate resource URLs across Modules 13–15: 0

## Practical
- Present: yes
- VM required: no
- Tasks, evidence, expected outcomes, grading, and progressive hints: validated

## Service Desk
- Present: yes
- Stages: Investigation → Diagnosis → Remediation → Verification → Documentation
- Rubric weights: 15 / 25 / 30 / 20 / 10
- Progressive hints: 3
- 3+ hint publication requirement: PASS
- Grading anchors: present
- Intended outcome: present
- Unsafe/incorrect actions: present

## Explain / Interview
- Prompt count: 4
- Stable key/objectives/expected concepts/minimum concepts/rubric/rubric version: PASS for every prompt

## Cross-module QA
- Exact duplicate questions: 0
- High-similarity near-duplicate questions: 0
- Stable-key collisions: 0
- Duplicate resource URLs: 0
- Duplicate lesson designs: none identified
- Repeated practicals: no
- Repeated Service Desk root causes: no
- Unnecessary Security-topic repetition: no; earlier knowledge is explicitly Review/Deep Dive where appropriate

## Remaining concerns
None blocking publication.

## Final verdict
**READY**
