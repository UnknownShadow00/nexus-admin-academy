---
certification: comptia_aplus
certification_version: comptia_aplus_220-1202
domain: '2.0'
module_key: module.aplus.core2.connected_endpoint_mobile_security
title: Connected Endpoint, Mobile & Browser Security
objectives:
- '2.3'
- '2.8'
- '2.10'
- '2.11'
- '3.2'
- '3.3'
---
# Connected Endpoint, Mobile & Browser Security

## Purpose
Secure and troubleshoot the user-facing edge of the environment: wireless access, SOHO routers, browsers, managed mobile devices, apps, profiles, and mobile security symptoms.

## Outcomes
Students learn to:
- select appropriate wireless security and recognize enterprise authentication components;
- harden a SOHO router without relying on weak obscurity controls;
- make safe browser/download/extension/certificate decisions;
- understand managed mobile-device controls and BYOD boundaries;
- troubleshoot ordinary mobile OS/app problems separately from security incidents;
- recognize mobile compromise indicators and preserve the managed security posture;
- use evidence before resetting profiles, wiping devices, or bypassing certificates.

## Relationship to earlier Nexus modules
- **Module 6:** Review mobile hardware/connectivity; Deep Dive into managed security and mobile troubleshooting.
- **Module 7:** Review wireless/network concepts; Deep Dive into secure wireless and SOHO configuration.
- **Module 12:** Review cross-platform application support; Deep Dive into secure mobile/browser application support.
- **Module 13:** Builds on least privilege and managed security controls without repeating Windows endpoint administration.
