---
certification: CompTIA A+
certification_version: comptia_aplus_220-1202
domain: 1.0 Operating Systems
module_key: module.aplus.core2.cross_platform_app_cloud_support
title: Cross-Platform Desktop, Applications & Cloud Productivity Support
objectives:
- '1.8'
- '1.9'
- '1.10'
- '1.11'
status: ready
---

# Module 12 — Cross-Platform Desktop, Applications & Cloud Productivity Support

This module teaches an A+-level technician to leave the Windows comfort zone and still collect useful evidence, make safe application-install decisions, and support cloud productivity users.

## Why these objectives belong together
macOS, Linux, application deployment, and cloud productivity all require the same entry-level support habits: **identify the platform, respect permissions, verify compatibility/ownership, collect evidence, and make the smallest safe change.**

## Prior Nexus relationships
- **Module 3 — Review:** operating-system support habits and client configuration.
- **Module 5 — Review:** authorization, handoff, documentation, and verification.
- **Module 7 — Review:** DNS/network evidence; this module uses it without reteaching networking.
- **Module 10 — Review:** cloud service/support boundaries; this module applies them to productivity tools.

## Scope boundary
This is not Linux Essentials, macOS administration, MDM engineering, Microsoft 365 administration, or Azure administration. Those topics are introduced only to the depth needed for A+ support work.
