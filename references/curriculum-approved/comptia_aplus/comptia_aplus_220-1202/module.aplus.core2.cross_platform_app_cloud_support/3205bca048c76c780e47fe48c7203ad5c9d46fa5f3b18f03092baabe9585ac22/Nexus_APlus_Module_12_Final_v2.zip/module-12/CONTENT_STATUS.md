# CONTENT STATUS — Module 12

**Cross-Platform Desktop, Applications & Cloud Productivity Support**

- Certification: CompTIA A+ V15
- Primary routing domain: 1.0 Operating Systems
- Official objectives: 1.8, 1.9, 1.10, 1.11
- Final verdict: **READY**

## Content inventory

- Lessons: **6**
- Questions: **32**
- Quick Check references: **24**
- Unique resources: **9**
- Required resources/videos: **6**
- Optional-only resources: **3**
- Explain prompts: **4**
- Practical: **Cross-Platform Support & Deployment Lab**
- Service Desk: **Productivity Suite Shows Unlicensed on Replacement Mac**

## Question distribution

- Single-choice: 24
- Multi-select: 4
- Short-answer: 2
- Free-response: 2

### Single-choice answer positions

- A: **6**
- B: **6**
- C: **6**
- D: **6**

## Objective distribution

- 1.8: 9 question mappings
- 1.9: 11 question mappings
- 1.10: 7 question mappings
- 1.11: 7 question mappings

Multi-objective questions are counted once under each genuinely mapped objective.

## Importance distribution

### Lessons
- working_knowledge: 1
- job_critical: 5

### Questions
- Working Knowledge: 9
- Job Critical: 23

## Question-style distribution

- Foundation: 16
- Scenario/Application: 9
- Troubleshooting/Reasoning: 7

## Reuse / provenance mix

- Strong existing Nexus concept adaptations: **8**
- Permitted third-party/source-guided adaptations: **8**
- Newly authored/source-guided gap-fill: **16**
- Total: **32**

## Quick Checks

- Lesson 1 — macOS Apps, File Types & System Folders: 4
- Lesson 2 — macOS Support Tools, Backups & Security Features: 4
- Lesson 3 — Linux Files, Permissions, Components & Configuration: 4
- Lesson 4 — Linux Administration, Packages, Storage & Network Evidence: 4
- Lesson 5 — Application Requirements, Distribution & Safe Deployment Decisions: 4
- Lesson 6 — Cloud Productivity, Sync, Identity & Licensing Support: 4

Every Quick Check references questions mapped to that lesson and taught by its lesson/resource content.

## Module Quiz

- Displayed questions: **12**
- Pass threshold: **70%**
- Blueprint uses objective/category constraints only where they improve coverage.
- A concrete 12-question witness form was validated against every quota/minimum; the selector is mathematically satisfiable.
- Free-response items are excluded from randomized module-quiz selection where specified by the blueprint.

## Resources

- All 9 resource URLs were rechecked during the batch and recorded as validated on **2026-08-31**.
- Required content is intentionally limited to one strong teaching spine per lesson where possible; optional references are supplemental.
- External resources are linked, not rehosted, and provenance/permission metadata is preserved.

## Practical status

- **READY:** Cross-Platform Support & Deployment Lab
- Objectives, tasks, evidence, expected outcomes, hints, VM requirement, grading rubric, and safety boundaries are present.

## Service Desk status

- Productivity Suite Shows Unlicensed on Replacement Mac
- Progressive hints: **3** (light investigation nudge → evidence/tool direction → strong next-step guidance); Nexus minimum-hint requirement satisfied.

## Explain status

- **4 prompts**
- Every prompt has a stable key, explicit objective relationship, expected concepts, minimum concepts, rubric, and rubric version.

## Editorial review

- APPROVE: **32**
- EDIT: **0**
- REPLACE: **0**
- REMOVE: **0**
- NEEDS SOURCE VERIFICATION: **0**

- Every final retained question was checked for technical correctness, current objective mapping, answer correctness, ambiguity, distractor quality, explanation, difficulty, job relevance, provenance, duplicate risk, and lesson/resource alignment.

## Final QA

- Lesson frontmatter and required lesson sections: PASS
- Lesson → required resource → Quick Check alignment: PASS
- Question → lesson → objective alignment: PASS
- Resource keys/lesson links: PASS
- Explain objective mappings: PASS
- Practical objective mappings: PASS
- Service Desk workflow/mappings when used: PASS
- Module Quiz satisfiability: PASS
- Cross-module stable-key collision check: PASS
- Cross-module exact/near-duplicate question check: PASS
- Cross-module duplicate resource URL check: PASS

## Remaining concerns

- None.

## Final verdict: **READY**
