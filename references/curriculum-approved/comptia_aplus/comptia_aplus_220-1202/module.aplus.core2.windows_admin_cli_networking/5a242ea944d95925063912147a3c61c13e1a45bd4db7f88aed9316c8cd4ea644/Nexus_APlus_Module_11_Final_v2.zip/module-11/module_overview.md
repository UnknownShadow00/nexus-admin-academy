---
certification: comptia_aplus
certification_version: comptia_aplus_220-1202
domain: '1.0'
module_key: module.aplus.core2.windows_admin_cli_networking
title: Windows Administration, Command Line & Client Networking
objectives:
- '1.3'
- '1.4'
- '1.5'
- '1.7'
---

# Windows Administration, Command Line & Client Networking

This module turns earlier Windows and networking knowledge into an operational desktop-support toolkit.

**Primary routing domain:** 1.0 Operating Systems  
**Official objectives:** 220-1202 1.3, 1.4, 1.5, 1.7

## Learning intent
Students identify Windows capability boundaries, select the right administrative tool, use command-line evidence safely, and troubleshoot client networking without broad or unauthorized changes.

## Relationship to earlier Nexus modules
- **Module 3:** Review/Deep Dive — Windows support tools and client configuration.
- **Module 4:** Review/Deep Dive — performance/startup/application evidence.
- **Modules 1 and 7:** Review — IP, DNS, network services and troubleshooting logic.
- **Module 5:** Review — documentation, authorization, escalation and verification.

This module deliberately does not reteach IP addressing, DNS fundamentals, or generic network devices.
