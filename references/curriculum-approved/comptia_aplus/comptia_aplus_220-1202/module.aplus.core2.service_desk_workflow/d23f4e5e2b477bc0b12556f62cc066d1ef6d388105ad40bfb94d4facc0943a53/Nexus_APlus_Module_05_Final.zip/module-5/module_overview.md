# Nexus A+ V15 — Module 5

## Module title
Service Desk Workflow, Documentation & Professional Communication

## Certification
CompTIA A+ V15

## Core
220-1202

## Official objectives
- **4.1** — Given a scenario, implement best practices associated with documentation and support systems information management.
- **4.2** — Given a scenario, apply change management procedures.
- **4.7** — Given a scenario, use proper communication techniques and professionalism.

Official source: https://assets.ctfassets.net/82ripq7fjls2/6I8WL66IBa1AUovioDGrnM/f74a7eca336fd4e4c8e723a1f893086d/CompTIA-A-220-1202-Exam-Objectives-3.0.pdf

## Curriculum grouping decision
CompTIA lists 4.1, 4.2, and 4.7 as separate objectives. Nexus groups them into one module because they form one workplace workflow:

**receive work → triage → document → communicate → escalate/change safely → verify → close/handoff**

That grouping is a Nexus curriculum decision, not an official CompTIA grouping.

## Why this module exists
The previous Nexus A+ modules teach technical support skills. This module teaches students to behave like technicians while using those skills. A correct technical fix is not enough if the student cannot prioritize the ticket, preserve evidence, communicate with the user, follow an approval process, verify the result, and leave a usable record.

## Importance
- Ticket intake, ownership, notes, escalation, verification: **Job Critical**
- SLA awareness and handoff quality: **Job Critical**
- Change planning and rollback thinking: **Job Critical**
- Professional communication: **Job Critical**
- Asset inventory/CMDB concepts: **Working Knowledge**
- SOPs, knowledge bases, onboarding/offboarding checklists: **Working Knowledge**
- Formal change-board terminology beyond what a junior technician uses daily: **Working Knowledge**

## Relationship to earlier Nexus material
- Ticket writing basics from legacy Nexus: **Review / Deep Dive**
- Troubleshooting evidence from Modules 1–4: **Deep Dive**
- Windows technical procedures: **Review only**; this module does not reteach them.
- Later ITIL material: **Future Deep Dive**
- Later security/admin modules: this workflow becomes the required documentation and escalation pattern.

## Lesson sequence
1. Ticket Intake, Triage & Ownership — Job Critical — New / Review
2. Internal Notes, User Updates & Resolution Notes — Job Critical — Review / Deep Dive
3. Assets, CMDBs, SOPs, Knowledge Bases & SLAs — Working Knowledge — New
4. Escalation, Handoffs & SLA Awareness — Job Critical — Deep Dive
5. Change Management Without Breaking Production — Job Critical — New
6. Professional Communication & Difficult Users — Job Critical — New / Deep Dive

## Required resources
Professor Messer's current 220-1202 V15 videos are the primary external teaching spine. Total required video time is about one hour, not several hours of duplicate content.

Course index: https://www.professormesser.com/free-a-plus-training/220-1202/220-1202-video/220-1202-training-course/

## Assessment design
- Question bank: **35 questions**
- Quick Checks: **3–5 questions per lesson**
- Module Quiz: **12 questions**, 70% threshold
- Practical: **Triage, Document, Escalate**
- Service Desk: **Yes — one guided workflow scenario**
- Explain / Interview prompts: **4**

## Reuse policy applied
This package does not replace strong existing Nexus material just to make it new. Eight strong questions from the legacy `Ticket Writing Fundamentals` bank were preserved/adapted, and useful legacy teaching on prioritization and communication was used as source material. Current CompTIA/Messer/ExamCompass material was used to fill objective gaps.

All reused/adapted material is tracked in `provenance.yaml` and the workbook's `Provenance` sheet.
