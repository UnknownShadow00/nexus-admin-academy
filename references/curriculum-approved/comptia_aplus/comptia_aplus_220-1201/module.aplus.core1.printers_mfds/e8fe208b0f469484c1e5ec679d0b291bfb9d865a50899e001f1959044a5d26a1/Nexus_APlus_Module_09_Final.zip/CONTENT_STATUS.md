# CONTENT STATUS — Module 9

**Module:** Printers, MFDs & Print Troubleshooting  
**Module key:** `module.aplus.core1.printers_mfds`  
**Certification:** CompTIA A+ 220-1201 V15  
**Objectives:** 3.7, 3.8, 5.6  
**Review date:** 2026-08-30  
**Final verdict:** **READY**

## Final counts
- Lessons: **5**
- Reviewed questions: **30**
- Quick Checks: **5** / **20 references**
- Module Quiz: **12 displayed**, **70% threshold**
- Practical: **1 — ready**
- Service Desk: **1 — ready**
- Explain prompts: **4 — ready**

## Question types
- Single-choice: **24**
- Multi-select: **3**
- Short-answer: **2**
- Free-response: **1**

## Correct-answer-position QA
- A: **6**
- B: **6**
- C: **6**
- D: **6**

Maximum share: **25.0%** — **PASS**.

## Objective distribution
- 3.7: **13**
- 3.8: **9**
- 5.6: **13**

## Importance distribution
- Job Critical: **20**
- Working Knowledge: **10**
- Awareness: **0**

## Question-style distribution
- Foundation: **11**
- Scenario/Application: **8**
- Troubleshooting/Reasoning: **11**

## Source / reuse mix
- Existing Nexus concept/fixture adaptations: **5**
- Owner-permitted ExamCompass source-guided rewrites: **7**
- Nexus-authored/source-guided current items: **18**
- Verbatim archived imports: **0**

## Editorial status
- APPROVE: **27**
- EDIT: **3**
- REPLACE: **0**
- REMOVE: **0**
- NEEDS SOURCE VERIFICATION: **0**

Final edits were applied to M9Q007, M9Q019, and M9Q030.

## Module Quiz structure
12 questions at 70%. Objective targets: 3.7=4, 3.8=3, 5.6=5. Category minimums ensure deployment, technology-specific maintenance, and troubleshooting all appear; at least seven scenario/reasoning items and one multi-select.

## Resources verified
Current Professor Messer V15 MFD/printer/maintenance/troubleshooting pages were checked. Microsoft current Windows printing guidance and HP model-specific print-quality documentation are optional references. No brain-dump source is used.

## Practical verdict
**READY.** The practical explicitly uses internal vs OS/application test pages, then maintenance and a queue scenario. No VM is required.

## Service Desk verdict
**READY.** The HR scenario adapts the existing Nexus fixture but grades client-path isolation using a neighboring known-good workstation; it does not repeat Module 7's network incident or Module 8's hardware/thermal incident.

## Explain count
**4**, each has explicit objectives and rubric `module9-explain-v1`.

## Cross-module duplicate review
- Module 7 owns general network diagnosis; Module 9 reuses only what is necessary to support network printers.
- Module 8 owns generic cable/mechanical fault isolation; Module 9 applies it to printer-specific mechanisms.
- Module 3 Windows services are reviewed only for Print Spooler/queue context.
- Module 5 documentation/verification standard is applied, not retaught.

## Remaining concerns
None blocking. Vendor-specific copier disassembly and advanced enterprise print administration are out of scope.

## Final verdict
**READY — complete, reviewed, aligned, and ready for Nexus curriculum-dropbox packaging.**
