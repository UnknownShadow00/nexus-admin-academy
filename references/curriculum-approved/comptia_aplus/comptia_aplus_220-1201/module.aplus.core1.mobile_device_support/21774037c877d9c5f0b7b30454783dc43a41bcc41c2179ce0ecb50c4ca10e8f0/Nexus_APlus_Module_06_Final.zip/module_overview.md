---
certification: comptia_aplus
certification_version: comptia_aplus_220-1201
domain: '1.0'
module_key: module.aplus.core1.mobile_device_support
module_title: Mobile Device Hardware, Connectivity & Troubleshooting
objectives:
- '1.1'
- '1.2'
- '1.3'
- '5.4'
status: ready
---

# Module 6 — Mobile Device Hardware, Connectivity & Troubleshooting

## Purpose
Build practical entry-level support skill for laptops, phones, and tablets: identify serviceable hardware, choose appropriate connections/accessories, configure basic mobile networking and synchronization, recognize MDM/BYOD context, and troubleshoot common mobile problems safely.

## Official objective scope
- **1.1** Given a scenario, monitor mobile device hardware and use appropriate replacement techniques.
- **1.2** Compare and contrast accessories and connectivity options for mobile devices.
- **1.3** Given a scenario, configure basic mobile device network connectivity and provide application support.
- **5.4** Given a scenario, troubleshoot common mobile device issues.

## Nexus grouping decision
CompTIA places 1.1–1.3 in Domain 1 and 5.4 in Domain 5. Nexus groups them into one job-oriented workflow:

**understand the device → connect it → support business use → troubleshoot symptoms → verify/document**

This is a curriculum grouping decision; it does not change the official CompTIA objective structure.

For Nexus routing, this module is stored under its **primary domain, 1.0 Mobile Devices**. Objective **5.4** remains explicitly linked as a cross-domain troubleshooting objective.

## Lessons
1. Mobile/Laptop Hardware & Safe Service — Working Knowledge — New
2. Ports, Accessories & Docking — Job Critical — New
3. Wi-Fi, Cellular, SIM/eSIM, Hotspots & Bluetooth — Job Critical — Deep Dive
4. MDM, BYOD, Corporate Devices & Business Sync — Working Knowledge — New
5. Battery, Charging, Screen & Physical Damage — Job Critical — New
6. Troubleshooting Mobile Connectivity, Apps & Performance — Job Critical — Deep Dive

## Relationship to earlier Nexus modules
- **Module 1:** mobile Wi-Fi/cellular isolation reuses the evidence-first connectivity habit; IPv4 itself is not retaught.
- **Module 2:** component/safety concepts are reviewed, but mobile/laptop serviceability and batteries are applied in a smaller form factor.
- **Module 5:** practical and Service Desk work reuse verification, documentation, escalation, and permission boundaries.

## Resource strategy
Professor Messer's current 220-1201 V15 mobile sections form the required video spine. Apple, Google, and Microsoft vendor documentation provide safety, tethering, and managed-device workplace context. No duplicate long video is added for Lesson 6; it is the application/deep-dive pass after the required troubleshooting video in Lesson 5.

## Assessment design
- 36-question reviewed source bank
- 6 Quick Checks, 4 questions each
- 12-question randomized Module Quiz, 70% threshold
- hands-on phone/tablet or simulated-evidence practical
- one Service Desk scenario
- four Explain/interview prompts

## Safety boundary
Students are never required to open, puncture, compress, or continue charging a suspected damaged/swollen battery. A safe escalation/replacement outcome can earn full credit.
