# CONTENT STATUS — Module 6

**Module:** Mobile Device Hardware, Connectivity & Troubleshooting  
**Module key:** `module.aplus.core1.mobile_device_support`  
**Certification:** CompTIA A+ 220-1201 V15  
**Objectives:** 1.1, 1.2, 1.3, 5.4  
**Review date:** 2026-08-30  
**Final verdict:** **READY**

## Final counts
- Lessons: **6**
- Reviewed questions: **36**
- Quick Checks: **6**
- Quick Check question references: **24** (4 per lesson)
- Module Quiz: **12 displayed**, **70% threshold**
- Practical: **1 — ready**
- Service Desk scenario: **1 — ready**
- Explain/interview prompts: **4 — ready**
- Student-facing resources: **10**
- Required Professor Messer videos: **6 unique videos**, total runtime **66:45**

## Question types
- Single-choice: **30**
- Multi-select: **4**
- Short-answer: **1**
- Free-response: **1**

## Objective mapping
Questions may map to more than one objective when the item genuinely assesses both.
- 1.1: **7**
- 1.2: **9**
- 1.3: **15**
- 5.4: **14**

## Importance distribution
- Job Critical: **23**
- Working Knowledge: **12**
- Awareness: **1**

## Question-style distribution
- Foundation: **9**
- Scenario/Application: **15**
- Troubleshooting/Reasoning: **12**

## Source / reuse mix
- Owner-permitted ExamCompass topic-bank source-guided rewrites: **12**
- Nexus-authored/source-guided current items: **24**
- Verbatim legacy Nexus imports: **0**

The historical Nexus Week 1 mobile bank contained 27 optional questions across Mobile Device Connection Methods, Hardware Servicing, Accessories, and Application Support. The prior Nexus editorial audit classified that set as mixed-to-weak, with missing explanations and unvalidated answer keys in the imported optional population. For Module 6, the legacy bank was treated as a candidate/topic source rather than bulk-imported. No legacy item was promoted without a fresh current-V15 review.

## Editorial gate
Every question was individually reviewed for:
- technical correctness
- current 220-1201 V15 scope
- answer-key correctness
- second defensible answers
- distractor quality
- explanation quality
- objective mapping
- multi-objective mapping
- difficulty
- job relevance
- duplication
- provenance
- lesson/resource alignment

Final dispositions:
- APPROVE: **32**
- EDIT: **4**
- REPLACE: **0**
- REMOVE: **0**
- NEEDS SOURCE VERIFICATION: **0**

Items revised during final review:
- **Q008:** clarified Lightning as an older-iPhone scenario so current USB-C devices are not misrepresented.
- **Q013:** added working-finger-touch evidence and stylus compatibility/pairing checks to remove digitizer ambiguity.
- **Q026:** strengthened swollen-battery safety language.
- **Q036:** required separate handling of the physical charging fault and mail-sync fault; factory reset is not a first move.

## Answer-position QA
Single-choice correct-answer distribution:
- A: **8**
- B: **7**
- C: **8**
- D: **7**

Maximum share: **26.7%**.  
Guardrail: no single position should exceed 40% without documented reason. **PASS.**

## Teaching / assessment alignment
All assessed concepts are taught through Nexus lesson text, a required resource, or prior content explicitly used as Review/Deep Dive.

Notable checks:
- 1.1 components: battery, keyboard/keys, RAM, HDD/SSD, wireless cards, biometrics/NFC features, Wi-Fi antennas, camera, microphone.
- 1.2: USB variants, Lightning, NFC, Bluetooth, tethering/hotspot, stylus/headset/speakers/webcam/dock/port replicator/input accessories.
- 1.3: Wi-Fi/cellular, 3G/4G/5G, SIM/eSIM, hotspot, Bluetooth pairing, location services, MDM, corporate/BYOD, policy, corporate apps, data caps, calendar/contacts/mail/cloud storage sync.
- 5.4: poor battery health, swollen battery, broken screen, improper charging, poor/no connectivity, liquid damage, overheating, digitizer, damaged ports, malware, cursor drift/calibration, app-install failure, stylus failure, degraded performance.

No hidden test-only concept was intentionally added.

## Module Quiz design
- 12 questions
- 70% threshold
- Objective target: 1.1 = 3, 1.2 = 2, 1.3 = 4, 5.4 = 3
- At least 7 scenario/application/reasoning questions
- At least 1 multi-select
- Category minimums enforce:
  - safe hardware/service
  - connection/accessory selection
  - mobile networking/sync
  - troubleshooting safety
  - integrated troubleshooting
- Q036 free-response excluded from randomized module quiz

## Practical
**Inspect, Isolate, and Document a Mobile Device** — READY.

- No VM required.
- Student may use an allowed phone/tablet or a supplied simulated evidence set.
- Includes device/accessory inspection, Wi-Fi/cellular isolation, Bluetooth/hotspot review, MDM/sync reasoning, one supplied symptom, documentation, and verification.
- Explicit privacy/redaction rules prevent collection of personal messages, phone numbers, exact location, credentials, serial/IMEI, or other private data.
- Unsafe battery/liquid/physical conditions require stopping and escalating rather than continuing the lab.

## Service Desk
**Field Phone Charges Intermittently and Mail Stopped Syncing** — READY.

Primary objectives:
- 1.3
- 5.4

Reinforces:
- 1.1
- 1.2

Stages are exactly:
Investigation → Diagnosis → Remediation → Verification → Documentation.

The scenario intentionally contains two symptoms. Full credit requires the student to avoid collapsing them into one assumed cause. Safe repair/replacement or MDM escalation can be the correct professional outcome.

## Explain / interview
Four prompts, all with explicit official objective mapping:
1. Swollen battery response — 5.4, 1.1
2. Wi-Fi isolation — 1.3, 5.4
3. MDM / corporate vs BYOD — 1.3
4. SIM/eSIM vs Wi-Fi — 1.3

Rubric version: `module6-explain-v1`.

## Resource validation
Validated during the 2026-08-30 research pass:
- Current CompTIA 220-1201 V15 objective PDF
- Professor Messer current 220-1201 V15 course and all six mobile/troubleshooting video pages
- Apple current device/battery safety documentation
- Android Help hotspot/tethering documentation
- Microsoft Learn Intune core concepts
- ExamCompass current 220-1201 mobile topic quizzes
- Crucial Exams current 220-1201 V15 practice page

No brain-dump source was used.

## Remaining notes
- Deep Intune administration is intentionally out of scope. Module 6 teaches only the A+-level MDM/BYOD/policy/application concepts.
- Mobile malware is introduced only to the level required by 5.4; broader security response will be developed in later A+ security modules.
- Lesson 6 intentionally reuses the required troubleshooting video from Lesson 5 instead of adding another redundant required video.
- The CompTIA six-step troubleshooting methodology is used as a job-practice framework, but it is not mislabeled as a formal 220-1201 objective.

## Final verdict
**READY — complete, reviewed, aligned, and packageable for the Nexus V2 curriculum dropbox.**
