---
certification: CompTIA A+
certification_version: comptia_aplus_220-1201
domain: 4.0 Virtualization and Cloud Computing
module_key: module.aplus.core1.virtualization_cloud_foundations
title: Virtualization & Cloud Foundations
objectives:
- '4.1'
- '4.2'
status: ready
---

# Module 10 — Virtualization & Cloud Foundations

This module closes the remaining **Core 1** V15 scope and teaches support-level virtualization/cloud reasoning without drifting into vendor-specific cloud administration.

## Why these objectives belong together
VMs, VDI, containers, and cloud services all require the same support reasoning: **where is the workload running, what resources does it depend on, and who owns the failing layer?**

## Prior Nexus relationships
- **Module 2 — Review/Deep Dive:** CPU/RAM/storage capacity and safe upgrades.
- **Module 7 — Review/Deep Dive:** network services/connectivity evidence.
- **Module 5 — Review:** approval/change discipline.

## Scope boundary
No Kubernetes, advanced orchestration, Azure/AWS administration, or datacenter engineering is required.
