# CONTENT STATUS — Module 8

**Module:** PC Hardware, Displays & Fault Isolation  
**Module key:** `module.aplus.core1.hardware_fault_isolation`  
**Certification:** CompTIA A+ 220-1201 V15  
**Objectives:** 3.1, 3.2, 3.3, 3.6, 5.1, 5.2, 5.3  
**Review date:** 2026-08-30  
**Final verdict:** **READY**

## Final counts
- Lessons: **6**
- Reviewed questions: **36**
- Quick Checks: **6** / **24 references**
- Module Quiz: **12 displayed**, **70% threshold**
- Practical: **1 — ready**
- Service Desk: **1 — ready**
- Explain prompts: **4 — ready**

## Question types
- Single-choice: **29**
- Multi-select: **3**
- Short-answer: **2**
- Free-response: **2**

## Correct-answer-position QA
- A: **8**
- B: **7**
- C: **7**
- D: **7**

Maximum share: **27.6%** — **PASS** under the 40% guardrail.

## Objective distribution
- 3.1: **5**
- 3.2: **5**
- 3.3: **5**
- 3.6: **5**
- 5.1: **8**
- 5.2: **6**
- 5.3: **7**


## Importance distribution
- Job Critical: **19**
- Working Knowledge: **17**
- Awareness: **0**

## Question-style distribution
- Foundation: **16**
- Scenario/Application: **4**
- Troubleshooting/Reasoning: **16**

## Source / reuse mix
- Nexus existing concept adaptations: **8**
- Owner-permitted ExamCompass source-guided rewrites: **8**
- Nexus-authored/source-guided current items: **20**
- Verbatim archived imports: **0**

## Editorial status
- APPROVE: **32**
- EDIT: **4**
- REPLACE: **0**
- REMOVE: **0**
- NEEDS SOURCE VERIFICATION: **0**

Final edits were applied to M8Q001, M8Q008, M8Q024, and M8Q035.

## Module Quiz structure
Objective targets: 3.1=2, 3.2=2, 3.3=1, 3.6=1, 5.1=2, 5.2=2, 5.3=2. At least seven scenario/reasoning items and one multi-select. Free-response questions are excluded from randomized forms.

## Resources verified
Current Professor Messer V15 display, cable, memory, power, and troubleshooting pages were checked. Dell monitor troubleshooting is optional vendor corroboration. No brain-dump material is used.

## Practical verdict
**READY.** Four stations test compatibility, POST/power/thermal isolation, data-safe storage handling, and display known-good comparisons. No VM required.

## Service Desk verdict
**READY.** The render-shutdown ticket uses explicit temperature/load evidence so students practice thermal diagnosis instead of repeating Module 7 network troubleshooting.

## Explain count
**4**, all explicitly mapped to objectives with rubric `module8-explain-v1`.

## Cross-module duplicate review
- Module 2 owns component recognition/upgrades; Module 8 is the Deep Dive into failure isolation.
- Module 7 owns network-layer troubleshooting; cable standards appear here only as hardware/connector scope.
- Printer mechanics remain reserved for Module 9.
- Module 3/4 OS evidence is referenced rather than retaught.

## Remaining concerns
None blocking. PSU board-level repair and professional data recovery are explicitly outside student scope.

## Final verdict
**READY — complete, reviewed, aligned, and ready for Nexus curriculum-dropbox packaging.**
