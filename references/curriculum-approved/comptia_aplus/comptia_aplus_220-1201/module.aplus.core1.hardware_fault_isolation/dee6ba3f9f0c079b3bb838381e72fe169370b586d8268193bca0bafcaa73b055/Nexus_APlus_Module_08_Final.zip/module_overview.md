---
certification: CompTIA A+
certification_version: comptia_aplus_220-1201
domain: 3.0 Hardware
module_key: module.aplus.core1.hardware_fault_isolation
title: PC Hardware, Displays & Fault Isolation
objectives:
- '3.1'
- '3.2'
- '3.3'
- '3.6'
- '5.1'
- '5.2'
- '5.3'
status: ready
---

# Module 8 — PC Hardware, Displays & Fault Isolation

## Purpose
Build on Module 2's component recognition and safe-upgrade skills by teaching students to diagnose display, memory, power, storage, POST, thermal, and cable/connector symptoms using evidence and known-good comparisons.

## Official objective scope
- **3.1** Display types and attributes.
- **3.2** Cables and connectors.
- **3.3** RAM types/features/configurations.
- **3.6** Power supplies, connectors, voltage, wattage, redundancy, efficiency.
- **5.1** Motherboard/RAM/CPU/power troubleshooting.
- **5.2** Storage/RAID troubleshooting.
- **5.3** Display troubleshooting.

## Nexus grouping decision
CompTIA places 3.x topics in Hardware and 5.x in Troubleshooting. Nexus routes the module under **3.0 Hardware** and uses one job-oriented flow:

**recognize the component/spec → collect symptom evidence → isolate with known-good tests → protect data/safety → repair or escalate → verify**

## Lessons
1. Displays: Types, Attributes & Choosing the Right Screen — Working Knowledge — New
2. Cables, Connectors & Adapters Without Guessing — Working Knowledge — New
3. RAM: DIMMs, SO-DIMMs, DDR, ECC & Channel Configurations — Working Knowledge — Deep Dive
4. PC Power Supplies, Connectors & Safe Replacement — Job Critical — Deep Dive
5. POST, No-Power, Thermal & Core Hardware Fault Isolation — Job Critical — Deep Dive
6. Storage, RAID & Display Troubleshooting — Job Critical — Deep Dive

## Relationship to earlier Nexus modules
- **Module 2 — primary Deep Dive prerequisite:** storage, motherboard, CPU, power, compatibility, and upgrade safety are assumed foundations.
- **Module 3 — Review:** Task Manager, Device Manager, Disk Management, and Event Viewer can provide OS-side evidence.
- **Module 4 — Review:** performance/startup symptoms may look like hardware symptoms; evidence separates them.
- **Module 5 — Review:** risky changes, data protection, verification, and escalation documentation remain mandatory.
- **Module 7 — Review:** network cable/connectors appear here as physical hardware standards; network troubleshooting stays owned by Module 7.

## Deliberately postponed
Printer hardware is Module 9. Deep server hardware, electrical engineering, board-level repair, and storage recovery procedures beyond entry-level safe handling are out of scope.
