---
certification: CompTIA A+
certification_version: comptia_aplus_220-1201
domain: 2.0 Networking
module_key: module.aplus.core1.network_services_troubleshooting
title: Network Services, Devices, Wireless & Troubleshooting
objectives:
- '2.1'
- '2.2'
- '2.3'
- '2.4'
- '2.5'
- '2.6'
- '2.7'
- '2.8'
- '5.5'
status: ready
---

# Module 7 — Network Services, Devices, Wireless & Troubleshooting

## Purpose
Turn the IP/DNS/DHCP foundation from Module 1 into practical A+-level network support skill. Students learn what common services and network devices do, how wireless and SOHO networks are built, which tools provide useful evidence, and how to isolate network symptoms without guessing.

## Official objective scope
- **2.1** Ports, protocols, and TCP/UDP.
- **2.2** Wireless networking technologies.
- **2.3** Network host services and appliances.
- **2.4** DNS records, DHCP configuration, VLANs, and VPNs.
- **2.5** Common networking devices, PoE, modems/ONTs, NICs, and MAC addresses.
- **2.6** Basic wired/wireless SOHO configuration and IP addressing concepts.
- **2.7** Internet connection types and network categories.
- **2.8** Common networking tools.
- **5.5** Troubleshoot common wired/wireless network symptoms.

## Nexus grouping decision
CompTIA places 2.1–2.8 in Domain 2 and 5.5 in Domain 5. Nexus uses **2.0 Networking** as the module routing domain and groups the troubleshooting objective with the concepts students need to diagnose:

**identify the service/device → collect evidence → isolate the path → choose the right tool → verify the original symptom → document**

## Lessons
1. Ports, Protocols & What Services Are Listening — Working Knowledge — New
2. Wireless Networks, Bands & Interference — Job Critical — Deep Dive
3. Network Host Services & Appliances — Working Knowledge — New
4. DNS, DHCP, VLANs & VPNs — Job Critical — Deep Dive
5. Routers, Switches, APs, Firewalls & PoE — Job Critical — New
6. SOHO Networks, Internet Types & Technician Tools — Job Critical — Deep Dive
7. Evidence-First Network Troubleshooting — Job Critical — Deep Dive

## Relationship to earlier Nexus modules
- **Module 1 — Deep Dive prerequisite:** IPv4, DHCP/APIPA, gateway, DNS, `ipconfig`, `ping`, and `nslookup` are not retaught from zero.
- **Module 3 — Review:** Windows support tools provide client-side evidence.
- **Module 5 — Review:** every practical/ticket uses clear investigation, verification, handoff, and documentation.
- **Module 6 — Review:** mobile Wi-Fi/Bluetooth concepts are reused; this module adds infrastructure, channels, services, and tools.

## Deliberately postponed
Network+ will later deepen subnetting, switching/routing, packet analysis, enterprise wireless design, and network architecture. This module stays at the A+ technician scope.
