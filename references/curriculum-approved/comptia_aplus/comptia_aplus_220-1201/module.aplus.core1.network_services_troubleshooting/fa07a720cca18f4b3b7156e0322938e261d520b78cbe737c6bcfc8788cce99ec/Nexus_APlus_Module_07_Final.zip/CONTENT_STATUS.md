# CONTENT STATUS — Module 7

**Module:** Network Services, Devices, Wireless & Troubleshooting  
**Module key:** `module.aplus.core1.network_services_troubleshooting`  
**Certification:** CompTIA A+ 220-1201 V15  
**Objectives:** 2.1–2.8, 5.5  
**Review date:** 2026-08-30  
**Final verdict:** **READY**

## Final counts
- Lessons: **7**
- Reviewed questions: **40**
- Quick Checks: **7**
- Quick Check references: **28**
- Module Quiz: **12 displayed**, **70% threshold**
- Practical: **1 — ready**
- Service Desk scenario: **1 — ready**
- Explain prompts: **4 — ready**

## Question types
- Single-choice: **32**
- Multi-select: **4**
- Short-answer: **2**
- Free-response: **2**

## Correct-answer-position QA — single choice
- A: **8**
- B: **8**
- C: **8**
- D: **8**

Maximum share: **25.0%**. Guardrail ≤40% — **PASS**.

## Objective distribution
- 2.1: **5**
- 2.2: **6**
- 2.3: **4**
- 2.4: **8**
- 2.5: **7**
- 2.6: **4**
- 2.7: **3**
- 2.8: **7**
- 5.5: **12**


## Importance distribution
- Job Critical: **22**
- Working Knowledge: **18**
- Awareness: **0**

## Question-style distribution
- Foundation: **20**
- Scenario/Application: **10**
- Troubleshooting/Reasoning: **10**

## Source / reuse mix
- Existing Nexus concept adaptations: **10**
- Owner-permitted ExamCompass source-guided rewrites: **8**
- Nexus-authored/source-guided current items: **22**
- Verbatim archived ExamCompass imports: **0**

## Editorial gate
Every item was reviewed for current V15 scope, answer key, ambiguity, distractors, explanation, objective mapping, difficulty, job relevance, duplication, provenance, and teaching alignment.

Final dispositions:
- APPROVE: **36**
- EDIT: **4**
- REPLACE: **0**
- REMOVE: **0**
- NEEDS SOURCE VERIFICATION: **0**

Final edits were applied to Q006, Q009, Q016, and Q038 to remove avoidable ambiguity.

## Quick Checks
Seven checks, four questions per lesson. They deliberately reuse prior IP/DNS evidence only as Review/Deep Dive rather than rebuilding Module 1.

## Module Quiz
12 questions, 70% threshold. Objective targets cover all nine official objectives, with three slots devoted to 5.5 troubleshooting. Category minimums prevent a form from becoming a ports-only memorization quiz. Free responses Q039/Q040 are excluded from randomized forms.

## Resources verified
Current Professor Messer 220-1201 V15 pages were checked during the 2026-08-30 research pass. Optional Crucial practice is linked, not copied. DNS/DHCP full videos are optional refreshers because Module 1 already taught those fundamentals.

## Practical verdict
**READY.** The practical uses a topology, service/port map, Wi-Fi evidence, physical-tool selection, and three distinct fault domains. No VM or real infrastructure changes are required.

## Service Desk verdict
**READY.** The loading-dock scenario adapts an existing Nexus workplace fixture but shifts grading toward radio/AP/PoE/uplink evidence and professional escalation. It is deliberately different from the client-only mobile ticket in Module 6.

## Explain count
**4**, all with explicit objective mappings and rubric version `module7-explain-v1`.

## Cross-module duplication notes
- Module 1 IP/APIPA/DNS commands are treated as Review/Deep Dive.
- Module 6 Wi-Fi/Bluetooth is reused as endpoint context; Module 7 owns infrastructure/bands/channels/APs/tools.
- Printer-specific networking is reserved for Module 9.
- Network+ depth is intentionally postponed.

## Remaining concerns
None blocking. Enterprise switching/routing depth is intentionally excluded from A+.

## Final verdict
**READY — complete, reviewed, aligned, and ready for Nexus curriculum-dropbox packaging.**
